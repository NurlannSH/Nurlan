#Complete the code block, print "YES" if 5 is larger than 2.

if 5 > 2:
    print("YES")