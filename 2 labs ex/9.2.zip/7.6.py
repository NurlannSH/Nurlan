#Print "Hello" if a is equal to b, or if c is equal to d.


if a == b or c == d:
  print("Hello")