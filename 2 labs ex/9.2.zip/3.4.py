#Use the insert method to add "lemon" as the second item in the fruits list.


fruits = ["apple", "banana", "cherry"]
fruits.insert(1, "lemon")