#Use the correct membership operator to check if "apple" is present in the fruits object.


fruits = ["apple", "banana"]
if "apple" in fruits:
 print("Yes, apple is a fruit!")