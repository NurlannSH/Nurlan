#Multiply 10 with 5, and print the result.


print(10 * 5)