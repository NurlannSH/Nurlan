#The statement below would print a Boolean value, which one?


print(bool("abc"))

True