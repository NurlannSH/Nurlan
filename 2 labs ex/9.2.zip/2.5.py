#Use the correct logical operator to check if at least one of two statements is True.


if 5 == 10 or 4 == 4:
  print("At least one of the statements is true")