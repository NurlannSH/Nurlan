#Stop the loop if i is 3.

i = 1
while i < 6:
  if i == 3:  
   break
  i += 1