print(100 > 9)

True