#Use the correct comparison operator to check if 5 is not equal to 10.


if 5 != 10:
  print("5 and 10 is not equal")