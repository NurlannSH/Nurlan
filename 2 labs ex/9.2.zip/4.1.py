#Use the correct syntax to print the first item in the fruits tuple.


fruits = ("apple", "banana", "cherry")
print(fruits[0])