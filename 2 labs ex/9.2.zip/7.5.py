#Print "Hello" if a is equal to b, and c is equal to d.


if a == b and c == d:
  print("Hello")