#Use a range of indexes to print the third, fourth, and fifth item in the tuple.


fruits = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
print(fruits[2:5])