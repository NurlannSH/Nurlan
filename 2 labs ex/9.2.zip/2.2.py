#Divide 10 by 2, and print the result.


print(10 / 2)