#Use the discard method to remove "banana" from the fruits set.


fruits = {"apple", "banana", "cherry"}
fruits.discard("banana")