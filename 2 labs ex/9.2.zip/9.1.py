#Print a message once the condition is false.


i = 1
while i < 6:
  print(i)
  i += 1
else:

  print("i is no longer less than 6")