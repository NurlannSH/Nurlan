#Print the second item in the fruits list.


fruits = ["apple", "banana", "cherry"]
print(fruits[1])