#Print i as long as i is less than 6.

i = 1
while i < 6:
  print(i)
  i += 1