#Use the range function to loop through a code set 6 times.


for x in range(6):
  print(x)