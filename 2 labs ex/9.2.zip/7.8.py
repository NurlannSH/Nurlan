#Use the correct one line short hand syntax to print "YES" if a is equal to b, otherwise print("NO").

a = 2
b = 5
print("YES") if a == b else print("NO")