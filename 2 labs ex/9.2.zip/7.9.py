#Use an if statement to print "YES" if either a or b is equal to c.


a = 2
b = 50
c = 2
if a == c or b == c:
  print("YES")