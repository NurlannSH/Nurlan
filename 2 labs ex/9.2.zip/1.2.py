#The statement below would print a Boolean value, which one?


print(10 == 9)

False