#Use the correct syntax to print the number of items in the fruits tuple.


fruits = ("apple", "banana", "cherry")
print(len(fruits))